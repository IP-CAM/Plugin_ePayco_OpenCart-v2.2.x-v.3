<?php
// Text
$_['text_title'] = 'Paga con tu Tarjeta de Crédito / Débito o Efectivo con (ePayco)';
$_['text_payment_description'] = 'Pago orden #';
$_['text_payment_description_in'] = 'en';