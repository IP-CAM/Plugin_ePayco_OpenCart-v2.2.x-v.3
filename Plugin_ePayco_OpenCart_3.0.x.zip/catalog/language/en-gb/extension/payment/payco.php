<?php
$_['text_title'] = 'Credit Card / Debit Card or Cash with (ePayco)';
$_['text_payment_description'] = 'Payment order #';
$_['text_payment_description_in'] = 'in';